export default function* funcionPrimaria() {
  // yield ES6
  console.log('Desde nuestra función generadora');
}

const CONSTANTES = {
  REGISTRO: 'REGISTRO',
  LOGIN: 'LOGIN',
};

export default CONSTANTES;
